import Foundation

struct Networking {
    
    let baseURLString = "https://retro.umoiq.com/service/publicJSONFeed?"
    
    func fetchRoutes(callback: @escaping ([Route]) -> ()) {
        // This would block user interactons, we want to do this on a background queue.
        // We can use the global queue for this.
        guard let url = URL(string: "\(baseURLString)command=routeList&a=sf-muni") else {
            return
        }
        let task = URLSession.shared.dataTask(with: url) { maybeData, maybeResponse, maybeError in
            guard let data: Data = maybeData else {
                return
            }
//            print(String(data: data, encoding: .utf8))
            let decoder = JSONDecoder()
            do {
                let response = try decoder.decode(RoutesResponse.self, from: data)
                let routes: [Route] = response.route
                callback(routes)
            } catch {
                
            }
        }
        task.resume()
    }
    
    
    // New and fancy way of makin request!
    func fetchRouteConfig(routeTag: String) async throws -> RouteConfig {
        let url = URL(string: "\(baseURLString)command=routeConfig&a=sf-muni&r=\(routeTag)")!
        let (data, _) = try await URLSession.shared.data(from: url)
        let decoder = JSONDecoder()
        return try decoder.decode(RouteConfig.self, from: data)
    }
    
    
    
    
    //Created this new function for making request for the predictions
    func fetchPredictionsConfig(routeTag:String, stopTag: String) async throws -> PredictionsConfig  {
        let url = URL(string: "\(baseURLString)command=predictions&a=sf-muni&r=\(routeTag)&s=\(stopTag)")!
        let (data, _) = try await  URLSession.shared.data(from: url)
        let decoder = JSONDecoder()
        return try decoder.decode(PredictionsConfig.self, from: data)
        
    }
}
