import UIKit

//All comments down below are observations of where I believe I made mistakes.


class PredicCell: UITableViewCell {
    
}

class PredictionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var route: Route?
    var stop: Stop?
    var directions: Direction?
    var predicitions: [Prediction] = []

    let networking = Networking()
    
    
    override func viewDidLoad() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(PredicCell.self, forCellReuseIdentifier: "PredicCell")
        navigationItem.title = stop?.title
        
        guard let route = route else {
            return
        }
        
        guard let stop = stop else {
            return
        }
        
        Task {
            do {
                let predicConfig = try await networking.fetchPredictionsConfig(routeTag: route.tag, stopTag: stop.tag)
                await MainActor.run {
                    predicitions = predicConfig.predictions.predicition
                    tableView.reloadData()
                }
            } catch {
                print("No Predictions")
            }
        }
        
    }
    
    
    @IBOutlet weak var tableView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //Believe this might be where the tableView display goes wrong. Seems like it only wants to display one
        // cell even thought there should be multiple predictions
        predicitions.count
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PredicCell") as? PredicCell else {
            return UITableViewCell()
        }
        //Also believe something went wrong here as well. Predictions text label although they should
        // if there were any predictions...
        let prediction = predicitions[indexPath.row]
        cell.textLabel?.text = prediction.agencyTitle
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //Not needed since we don't need to dispaly another viewController
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //Not needed since we don't need to pass data to another viewController
    }
}
