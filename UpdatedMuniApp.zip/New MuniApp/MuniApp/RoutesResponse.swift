import Foundation

struct RoutesResponse: Codable {
    let copyright: String
    let route: [Route]
}

struct Route: Codable {
    let tag: String
    let title: String
    
//    enum Keys: CodingKey {
//        case tag, title
//    }
//
//    init(from decoder: Decoder) throws {
//        let container = try decoder.container(keyedBy: Keys.self)
//        tag = try container.decode(String.self, forKey: .tag)
//        title = try container.decode(String.self, forKey: .title)
//    }
//
//    func encode(to encoder: Encoder) throws {
//        var container = encoder.container(keyedBy: Keys.self)
//        try container.encode(title, forKey: .title)
//        try container.encode(tag, forKey: .tag)
//    }
}
