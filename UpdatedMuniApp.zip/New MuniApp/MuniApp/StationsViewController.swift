import UIKit

class StopCell: UITableViewCell {
    
}

class StationsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var route: Route?
    
    var stops: [Stop] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    let networking = Networking()
    
    override func viewDidLoad() {
        // Here you can populate Lables, TextFileds.... If you do it from prepareForSqueue the app will crash!!!!
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(StopCell.self, forCellReuseIdentifier: "StopCell")
        navigationItem.title = route?.title
        
        guard let route = route else {
            return
        }
        // Inside tasks we can call asynchronous functions!
        Task {
            do {
                let routeConfig = try await networking.fetchRouteConfig(routeTag: route.tag)
                await MainActor.run {
                    stops = routeConfig.route.stop
                    tableView.reloadData()
                }
            } catch {
                print(error)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        stops.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "StopCell") as? StopCell else {
            return UITableViewCell()
        }
        let stop = stops[indexPath.row]
        cell.textLabel?.text = stop.title
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //Added this segue to segue to PredictionsViewController
        performSegue(withIdentifier: "ToPredictionsSegue", sender: indexPath)
    }
    //Added this func to pass over the stop data to the PredictionsViewController
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let predictionsViewController = segue.destination as? PredictionsViewController else {
            return
        }
        guard let indexPath = sender as? IndexPath else {
            return
        }
        let stop = stops[indexPath.row]
        predictionsViewController.stop = stop
    }
    
}
