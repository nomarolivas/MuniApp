//  Created by SFSU on 3/3/22.
//

import Foundation

struct Stop: Codable {
    let tag: String
    let title: String
}

struct Direction: Codable {
    struct StopTag: Codable {
        let tag: String
    }
    let stop: [StopTag]

}

struct RouteConfig: Codable {
    struct Route: Codable {
        let stop: [Stop]
        let direction: [Direction]
    }
    let route: Route
}

//Added these 2 structs down below

struct Prediction: Codable {
    let routeTag: String
    let stopTag: String
    let routeTitle: String
    let agencyTitle: String
    let stopTitle: String
    let route: [Route]
    let stop: [Stop]
    let direction: [Direction]
}


struct PredictionsConfig: Codable {
    struct Predictions: Codable {
        let route: [Route]
        let stop: [Stop]
        let direction: [Direction]
        let predicition: [Prediction]
    }
    
    let predictions: Predictions
    

}


    
    


